#define PACKAGE "csv2latex"
#define RELEASE_DATE "2016-10-24"
#define VERSION "0.20"

